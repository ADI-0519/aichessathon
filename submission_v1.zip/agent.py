"""The submission entrypoint. The platform imports this file and calls get_move."""

import time
from collections.abc import Hashable
from dataclasses import dataclass

import chess

PIECE_VALUES = {
    chess.PAWN: 100,
    chess.KNIGHT: 320,
    chess.BISHOP: 330,
    chess.ROOK: 500,
    chess.QUEEN: 900,
    chess.KING: 0,
}
MATE_SCORE = 100_000
INFINITY = 1_000_000
MAX_QUIESCENCE_PLY = 8
BISHOP_PAIR_BONUS = 30
MOBILITY_WEIGHT = 2

PAWN_TABLE = (
    0, 0, 0, 0, 0, 0, 0, 0,
    50, 50, 50, 50, 50, 50, 50, 50,
    10, 10, 20, 30, 30, 20, 10, 10,
    5, 5, 10, 25, 25, 10, 5, 5,
    0, 0, 0, 20, 20, 0, 0, 0,
    5, -5, -10, 0, 0, -10, -5, 5,
    5, 10, 10, -20, -20, 10, 10, 5,
    0, 0, 0, 0, 0, 0, 0, 0,
)
KNIGHT_TABLE = (
    -50, -40, -30, -30, -30, -30, -40, -50,
    -40, -20, 0, 5, 5, 0, -20, -40,
    -30, 5, 10, 15, 15, 10, 5, -30,
    -30, 0, 15, 20, 20, 15, 0, -30,
    -30, 5, 15, 20, 20, 15, 5, -30,
    -30, 0, 10, 15, 15, 10, 0, -30,
    -40, -20, 0, 0, 0, 0, -20, -40,
    -50, -40, -30, -30, -30, -30, -40, -50,
)


@dataclass
class TableEntry:
    depth: int
    score: int
    flag: int
    move: chess.Move | None


class SearchTimeout(Exception):
    pass


class Searcher:
    def __init__(self, deadline: float) -> None:
        self.deadline = deadline
        self.table: dict[Hashable, TableEntry] = {}
        self.nodes = 0

    def check_time(self) -> None:
        self.nodes += 1
        # A python-chess node can be expensive: it may generate and sort dozens of moves.
        # Checking only every few hundred nodes can overrun a small move budget by seconds.
        if time.monotonic() >= self.deadline:
            raise SearchTimeout

    def evaluate(self, board: chess.Board) -> int:
        score = 0
        for square, piece in board.piece_map().items():
            value = PIECE_VALUES[piece.piece_type]
            table_square = square if piece.color else chess.square_mirror(square)
            if piece.piece_type == chess.PAWN:
                value += PAWN_TABLE[table_square]
            elif piece.piece_type == chess.KNIGHT:
                value += KNIGHT_TABLE[table_square]
            signed = value if piece.color == board.turn else -value
            score += signed
        if len(board.pieces(chess.BISHOP, board.turn)) >= 2:
            score += BISHOP_PAIR_BONUS
        if len(board.pieces(chess.BISHOP, not board.turn)) >= 2:
            score -= BISHOP_PAIR_BONUS
        score += MOBILITY_WEIGHT * board.legal_moves.count()
        return score

    def terminal_score(self, board: chess.Board, ply: int) -> int | None:
        if board.is_checkmate():
            return -MATE_SCORE + ply
        if board.is_stalemate() or board.is_insufficient_material():
            return 0
        return None

    def move_score(self, board: chess.Board, move: chess.Move) -> int:
        score = 0
        if board.is_capture(move):
            victim = board.piece_at(move.to_square)
            attacker = board.piece_at(move.from_square)
            if victim is None and board.is_en_passant(move):
                victim_value = PIECE_VALUES[chess.PAWN]
            else:
                victim_value = PIECE_VALUES[victim.piece_type] if victim else 0
            attacker_value = PIECE_VALUES[attacker.piece_type] if attacker else 0
            score += 10 * victim_value - attacker_value
        if move.promotion:
            score += PIECE_VALUES[move.promotion]
        if board.gives_check(move):
            score += 500
        return score

    def ordered_moves(
        self, board: chess.Board, hash_move: chess.Move | None = None
    ) -> list[chess.Move]:
        moves = list(board.legal_moves)
        moves.sort(key=lambda move: (move != hash_move, -self.move_score(board, move)))
        return moves

    def quiescence(
        self, board: chess.Board, alpha: int, beta: int, ply: int, qply: int = 0
    ) -> int:
        self.check_time()
        terminal = self.terminal_score(board, ply)
        if terminal is not None:
            return terminal
        in_check = board.is_check()
        if in_check:
            moves = self.ordered_moves(board)
        elif qply >= MAX_QUIESCENCE_PLY:
            return self.evaluate(board)
        else:
            stand_pat = self.evaluate(board)
            if stand_pat >= beta:
                return stand_pat
            alpha = max(alpha, stand_pat)
            moves = self.ordered_moves(board)
            moves = [move for move in moves if board.is_capture(move) or move.promotion]
        best = self.evaluate(board) if not in_check else -INFINITY
        for move in moves:
            board.push(move)
            try:
                score = -self.quiescence(board, -beta, -alpha, ply + 1, qply + 1)
            finally:
                board.pop()
            best = max(best, score)
            alpha = max(alpha, score)
            if alpha >= beta:
                break
        return best

    def search(self, board: chess.Board, depth: int, alpha: int, beta: int, ply: int) -> int:
        self.check_time()
        terminal = self.terminal_score(board, ply)
        if terminal is not None:
            return terminal
        if depth == 0:
            return self.quiescence(board, alpha, beta, ply)

        key = board._transposition_key()
        entry = self.table.get(key)
        original_alpha = alpha
        original_beta = beta
        if entry and entry.depth >= depth:
            if entry.flag == 0:
                return entry.score
            if entry.flag == 1:
                alpha = max(alpha, entry.score)
            elif entry.flag == 2:
                beta = min(beta, entry.score)
            if alpha >= beta:
                return entry.score

        best = -INFINITY
        best_move = None
        for move in self.ordered_moves(board, entry.move if entry else None):
            board.push(move)
            try:
                score = -self.search(board, depth - 1, -beta, -alpha, ply + 1)
            finally:
                board.pop()
            if score > best:
                best = score
                best_move = move
            alpha = max(alpha, score)
            if alpha >= beta:
                break

        flag = 2 if best <= original_alpha else (1 if best >= original_beta else 0)
        self.table[key] = TableEntry(depth, best, flag, best_move)
        return best

    def best_move(self, board: chess.Board, max_depth: int) -> chess.Move:
        legal_moves = self.ordered_moves(board)
        best_move = legal_moves[0]
        for depth in range(1, max_depth + 1):
            try:
                score = -INFINITY
                candidate = best_move
                alpha = -INFINITY
                for move in self.ordered_moves(board, best_move):
                    board.push(move)
                    try:
                        value = -self.search(board, depth - 1, -INFINITY, -alpha, 1)
                    finally:
                        board.pop()
                    if value > score:
                        score = value
                        candidate = move
                    alpha = max(alpha, value)
                best_move = candidate
            except SearchTimeout:
                break
        return best_move


def get_move(fen: str, time_left_ms: int) -> str:
    """Return a legal move in UCI notation.

    fen           the position to move in; your colour is the side to move
    time_left_ms  your clock before this move, in milliseconds
    returns       "e2e4", or "e7e8q" for a promotion

    The process stays alive between your moves, so state you keep on a module or in a
    closure survives to the next call. It does not survive to the next game.

    print() is safe. Your stdout is redirected away from the protocol stream, discarded
    during rated games and shown back to you in the validation log.
    """
    board = chess.Board(fen)
    legal_moves = list(board.legal_moves)
    if not legal_moves:
        raise ValueError("position has no legal moves")
    if len(legal_moves) == 1:
        return legal_moves[0].uci()

    # Keep a hard reserve. At very low time, returning the fallback immediately is
    # stronger than starting a search that might flag.
    reserve_ms = max(75, min(1_000, time_left_ms // 10))
    usable_ms = time_left_ms - reserve_ms
    if usable_ms <= 10:
        return legal_moves[0].uci()

    # Roughly one forty-fifth of the clock plus part of the known 500 ms increment.
    # The hard reserve remains outside this budget even if the position is expensive.
    target_ms = min(3_000, time_left_ms // 45 + 200)
    budget_ms = max(1, min(target_ms, usable_ms))
    deadline = time.monotonic() + budget_ms / 1000.0
    try:
        return Searcher(deadline).best_move(board, 8).uci()
    except Exception as error:
        # A legal fallback is preferable to forfeiting a whole game. The platform
        # redirects this diagnostic safely into the validation log.
        print(f"search failed, using fallback: {type(error).__name__}: {error}")
        return legal_moves[0].uci()
